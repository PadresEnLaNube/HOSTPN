(function($) {
	'use strict';

})(jQuery);